from distutils.core import setup

setup(name="ExcelNmon", version="1.0", description="调用 excel 宏解析 nmon 文件", author="zln", py_modules=['nmon.ExcelMicro', 'nmon.NmonResult'])